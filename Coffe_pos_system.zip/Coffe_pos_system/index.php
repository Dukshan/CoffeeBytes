<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
<title>Login - CoffeeBytes</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body {
    background: linear-gradient(135deg, #3e2723, #6f4e37);
    font-family: "Segoe UI", sans-serif;
}

.login-card {
    width: 360px;
    border-radius: 16px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.3);
    overflow: hidden;
}

.brand-header {
    background: #4b2e1e;
    color: #fff;
    text-align: center;
    padding: 18px;
}

.brand-header h2 {
    margin: 0;
    font-weight: 700;
    letter-spacing: 1px;
}

.brand-header small {
    color: #d7ccc8;
}

.login-body {
    background: #fff;
    padding: 25px;
}

.form-control {
    border-radius: 10px;
    border: 1px solid #ddd;
    padding: 10px;
}

.btn-coffee {
    background: #6f4e37;
    color: #fff;
    border-radius: 10px;
    font-weight: 600;
}

.btn-coffee:hover {
    background: #5a3d2b;
}
</style>
</head>

<body class="d-flex justify-content-center align-items-center vh-100">

<div class="login-card">

    <?php if (isset($_GET['error']) && $_GET['error'] == 1): ?>
        <div class="alert alert-danger text-center py-2 m-0">
            Invalid username or password
        </div>
    <?php endif; ?>

    <div class="brand-header">
        <h2>CoffeeBytes ☕</h2>
        <small>Inventory & POS System</small>
    </div>

    <div class="login-body">
       <form action="includes/auth.php" method="POST">
            <h5 class="mb-3" style="color:#4b2e1e; font-weight:600;">
                Coffee Shop Inventory & POS
            </h5>

            <input class="form-control mb-2" name="username" placeholder="Username" required>
            <input type="password" class="form-control mb-3" name="password" placeholder="Password" required>

            <button class="btn btn-coffee w-100" type="submit">Login</button>
        </form>
    </div>

</div>

</body>
</html>