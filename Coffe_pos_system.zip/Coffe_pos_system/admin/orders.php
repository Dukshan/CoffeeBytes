<?php
session_start();

include("../includes/functions.php");
include("../config/db.php");

/* =========================
   ROLE
========================= */
$role = $_SESSION['role'] ?? 'staff';

$isStaff = ($role === 'staff');
$isAdmin = ($role === 'admin');

/* =========================
   UPDATE STATUS + LOGS
========================= */
if (isset($_POST['update'])) {

    if ($isAdmin || $isStaff) {

        $id = intval($_POST['id']);
        $status = $_POST['status'];

        // CURRENT USER
        $user_id = $_SESSION['user']['user_id'] ?? 0;

        /* =========================
           UPDATE ORDER
        ========================= */

        if ($status == "Cancelled") {

            $conn->query("
                UPDATE orders 
                SET status='Cancelled', deleted_at=NOW()
                WHERE order_id=$id
            ");

        } else {

            $stmt = $conn->prepare("
                UPDATE orders 
                SET status=? 
                WHERE order_id=?
            ");

            $stmt->bind_param("si", $status, $id);
            $stmt->execute();
        }

        /* =========================
           INSERT LOG
        ========================= */

        $action = "Order Update";
        $details = "Updated Order #$id to $status";

        $logStmt = $conn->prepare("
            INSERT INTO logs(user_id, action, details)
            VALUES (?, ?, ?)
        ");

        $logStmt->bind_param(
            "iss",
            $user_id,
            $action,
            $details
        );

        $logStmt->execute();
    }

    header("Location: orders.php");
    exit();
}

/* =========================
   FETCH ORDERS
========================= */

$orders = $conn->query("
    SELECT 
        o.order_id,
        o.total,
        o.status,

        GROUP_CONCAT(
            CONCAT(
                COALESCE(p.name, 'Unknown Item'),
                ' x',
                oi.quantity
            )
            SEPARATOR '<br>'
        ) AS items

    FROM orders o

    LEFT JOIN order_items oi 
        ON o.order_id = oi.order_id

    LEFT JOIN products p 
        ON oi.product_id = p.product_id

    WHERE o.deleted_at IS NULL
    AND o.status != 'Completed'

    GROUP BY o.order_id, o.total, o.status

    ORDER BY o.order_id DESC
");

if (!$orders) {
    die("SQL Error: " . $conn->error);
}
?>

<!DOCTYPE html>
<html>
<head>

<title>Coffee Shop Orders</title>

<style>

body{
    margin:0;
    font-family:'Segoe UI', sans-serif;
    background:#f7f3ee;
    color:#2b1d16;
}

.layout{
    display:flex;
    min-height:100vh;
}

/* SIDEBAR */
.sidebar{
    width:260px;
    background:linear-gradient(180deg,#3b2f2f,#2a1f1b);
    color:#f5e6d3;
    padding:25px 20px;
}

.sidebar h2{
    color:#fff;
    text-align:center;
    margin-bottom:30px;
    font-size:28px;
    font-weight:800;
}

.sidebar a{
    display:block;
    padding:12px;
    margin-bottom:10px;
    color:#e8d5c0;
    text-decoration:none;
    border-radius:10px;
}

.sidebar a:hover{
    background:#5a3e36;
    color:#fff;
}

/* LOGOUT BUTTON */
.logout-btn{
    margin-top:40px;
    background:#b23b3b;
    color:white !important;
    text-align:center;
    font-weight:bold;
}

.logout-btn:hover{
    background:#912f2f !important;
}

/* MAIN */
.main{
    flex:1;
    padding:30px;
}

h2{
    color:#3b2f2f;
    margin-bottom:20px;
}

/* BACK BUTTON */
.back-btn{
    display:inline-block;
    padding:10px 15px;
    background:#5a3e36;
    color:white;
    border-radius:10px;
    text-decoration:none;
    margin-bottom:15px;
}

.back-btn:hover{
    background:#3b2f2f;
}

/* RECEIPT STYLE */
.orders-container{
    display:flex;
    flex-direction:column;
    gap:20px;
}

.receipt-card{
    background:white;
    border-radius:16px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
    padding:20px;
    border-left:6px solid #3b2f2f;
}

.receipt-header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:15px;
}

.receipt-header h3{
    margin:0;
    color:#3b2f2f;
}

.items-list{
    background:#faf7f3;
    padding:10px;
    border-radius:10px;
    font-size:14px;
    line-height:1.6;
}

.receipt-total{
    margin-top:12px;
    font-size:16px;
}

/* BADGES */
.badge{
    padding:6px 12px;
    border-radius:20px;
    font-size:12px;
    color:white;
    font-weight:bold;
}

.pending{ background:#c69c6d; }
.preparing{ background:#5a3e36; }
.completed{ background:#2e7d32; }
.cancelled{ background:#8b3a3a; }

/* FORM */
form{
    display:flex;
    gap:8px;
    align-items:center;
    margin-top:15px;
}

select{
    padding:8px;
    border-radius:8px;
    border:1px solid #ddd;
}

button{
    padding:8px 12px;
    border:none;
    border-radius:8px;
    background:#3b2f2f;
    color:white;
    cursor:pointer;
}

button:hover{
    background:#2a1f1b;
}

</style>

</head>

<body>

<div class="layout">

<!-- SIDEBAR -->
<div class="sidebar">

    <h2>☕ CoffeeBytes</h2>

    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="products.php">📦 Products</a>
    <a href="orders.php">🛒 Orders</a>
    <a href="recipes.php">🍹 Recipes</a>
    <a href="reports.php">📊 Reports</a>

    <?php if (in_array($_SESSION['role'], ['admin', 'superuser'])): ?>
        <a href="users.php">👥 Users</a>
        <a href="logs.php">📜 Activity Logs</a>
    <?php endif; ?>

    <a href="inventory.php">🧪 Inventory</a>

</div>

<!-- MAIN -->
<div class="main">

<?php
$dashboard_link = ($_SESSION['role'] === 'staff')
    ? "../staff/staff_dashboard.php"
    : "dashboard.php";
?>

<a href="<?= $dashboard_link ?>" class="back-btn">
    ← Back to Dashboard
</a>

<h2>☕ Orders Management</h2>

<div class="orders-container">

<?php if ($orders && $orders->num_rows > 0): ?>

    <?php while($o = $orders->fetch_assoc()): ?>

    <div class="receipt-card">

        <div class="receipt-header">

            <h3>Order #<?= $o['order_id'] ?></h3>

            <?php $statusClass = strtolower($o['status']); ?>

            <span class="badge <?= $statusClass ?>">
                <?= $o['status'] ?>
            </span>

        </div>

        <div class="items-list">
            <?= $o['items'] ?? 'No items found' ?>
        </div>

        <div class="receipt-total">
            Total: <strong>₱<?= number_format($o['total'], 2) ?></strong>
        </div>

        <?php if ($isAdmin || $isStaff): ?>

        <form method="POST">

            <input type="hidden" name="id" value="<?= $o['order_id'] ?>">

            <select name="status">

                <option value="Pending"
                    <?= $o['status']=="Pending" ? "selected" : "" ?>>
                    Pending
                </option>

                <option value="Preparing"
                    <?= $o['status']=="Preparing" ? "selected" : "" ?>>
                    Preparing
                </option>

                <option value="Completed"
                    <?= $o['status']=="Completed" ? "selected" : "" ?>>
                    Completed
                </option>

                <option value="Cancelled"
                    <?= $o['status']=="Cancelled" ? "selected" : "" ?>>
                    Cancelled
                </option>

            </select>

            <button name="update">
                Update
            </button>

        </form>

        <?php endif; ?>

    </div>

    <?php endwhile; ?>

<?php else: ?>

    <p>No orders found.</p>

<?php endif; ?>

</div>

</div>
</div>

</body>
</html>