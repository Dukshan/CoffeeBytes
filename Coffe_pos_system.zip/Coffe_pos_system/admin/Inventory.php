<?php
session_start();

include("../includes/functions.php");
include("../config/db.php");

/* =========================
   ACCESS CONTROL
========================= */
if (!isset($_SESSION['role'])) {
    header("Location: ../index.php");
    exit();
}

$user_id = $_SESSION['user_id'] ?? 0;

/* =========================
   ADD INGREDIENT
========================= */
if (isset($_POST['add'])) {

    $name        = trim($_POST['name']);
    $stock       = floatval($_POST['stock']);
    $min         = floatval($_POST['min']);
    $unit        = $_POST['unit'];
    $expiration  = $_POST['expiration_date'];

    if (empty($expiration)) {
        echo "<script>alert('Expiration date is required!');window.history.back();</script>";
        exit();
    }

    $stmt = $conn->prepare("
        INSERT INTO ingredients (
            name,
            stock,
            min_stock_ml,
            unit,
            expiration_date
        )
        VALUES (?, ?, ?, ?, ?)
    ");

    if (!$stmt) {
        die("Prepare Failed: " . $conn->error);
    }

    $stmt->bind_param("sddss", $name, $stock, $min, $unit, $expiration);
    $stmt->execute();

    /* LOG */
    $action = "ADD INGREDIENT";
    $details = "Added ingredient: $name | Stock: $stock $unit";

    $log = $conn->prepare("
        INSERT INTO logs (user_id, action, details)
        VALUES (?, ?, ?)
    ");

    if ($log) {
        $log->bind_param("iss", $user_id, $action, $details);
        $log->execute();
    }

    header("Location: inventory.php");
    exit();
}

/* =========================
   RESTOCK
========================= */
if (isset($_POST['restock'])) {

    $id         = intval($_POST['id']);
    $amount     = floatval($_POST['amount']);
    $expiration = $_POST['expiration_date'];

    if (empty($expiration)) {
        echo "<script>alert('Expiration date is required!');window.history.back();</script>";
        exit();
    }

    $ingredient = $conn->query("SELECT * FROM ingredients WHERE ingredient_id=$id");
    $ingredientData = $ingredient->fetch_assoc();

    $stmt = $conn->prepare("
        UPDATE ingredients
        SET stock = stock + ?, expiration_date = ?
        WHERE ingredient_id = ?
    ");

    if (!$stmt) {
        die("Prepare Failed: " . $conn->error);
    }

    $stmt->bind_param("dsi", $amount, $expiration, $id);
    $stmt->execute();

    /* LOG */
    $ingredientName = $ingredientData['name'];

    $action = "RESTOCK";
    $details = "Restocked $ingredientName by $amount {$ingredientData['unit']}";

    $log = $conn->prepare("
        INSERT INTO logs (user_id, action, details)
        VALUES (?, ?, ?)
    ");

    if ($log) {
        $log->bind_param("iss", $user_id, $action, $details);
        $log->execute();
    }

    header("Location: inventory.php");
    exit();
}

/* =========================
   DEDUCT STOCK
========================= */
if (isset($_POST['deduct'])) {

    $id     = intval($_POST['id']);
    $amount = floatval($_POST['amount']);

    $ingredient = $conn->query("SELECT * FROM ingredients WHERE ingredient_id=$id");
    $ingredientData = $ingredient->fetch_assoc();

    $stmt = $conn->prepare("
        UPDATE ingredients
        SET stock = stock - ?
        WHERE ingredient_id = ?
    ");

    if (!$stmt) {
        die("Prepare Failed: " . $conn->error);
    }

    $stmt->bind_param("di", $amount, $id);
    $stmt->execute();

    /* LOG */
    $ingredientName = $ingredientData['name'];

    $action = "DEDUCT";
    $details = "Deducted $amount {$ingredientData['unit']} from $ingredientName";

    $log = $conn->prepare("
        INSERT INTO logs (user_id, action, details)
        VALUES (?, ?, ?)
    ");

    if ($log) {
        $log->bind_param("iss", $user_id, $action, $details);
        $log->execute();
    }

    header("Location: inventory.php");
    exit();
}

/* =========================
   DELETE INGREDIENT
========================= */
if (isset($_POST['delete'])) {

    $id = intval($_POST['id']);

    $ingredient = $conn->query("SELECT * FROM ingredients WHERE ingredient_id=$id");
    $ingredientData = $ingredient->fetch_assoc();

    $stmt = $conn->prepare("DELETE FROM ingredients WHERE ingredient_id=?");

    if (!$stmt) {
        die("Prepare Failed: " . $conn->error);
    }

    $stmt->bind_param("i", $id);
    $stmt->execute();

    /* LOG */
    $ingredientName = $ingredientData['name'];

    $action = "DELETE INGREDIENT";
    $details = "Deleted ingredient: $ingredientName";

    $log = $conn->prepare("
        INSERT INTO logs (user_id, action, details)
        VALUES (?, ?, ?)
    ");

    if ($log) {
        $log->bind_param("iss", $user_id, $action, $details);
        $log->execute();
    }

    header("Location: inventory.php");
    exit();
}

/* =========================
   FETCH DATA + SEARCH
========================= */

$search = $_GET['search'] ?? '';

if (!empty($search)) {

    $searchValue = "%" . $search . "%";

    $stmt = $conn->prepare("
        SELECT *
        FROM ingredients
        WHERE name LIKE ?
        ORDER BY ingredient_id DESC
    ");

    if (!$stmt) {
        die("Search Prepare Failed: " . $conn->error);
    }

    $stmt->bind_param("s", $searchValue);
    $stmt->execute();

    $result = $stmt->get_result();

} else {

    $result = $conn->query("
        SELECT *
        FROM ingredients
        ORDER BY ingredient_id DESC
    ");
}

if (!$result) {
    die("Inventory Query Failed: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Inventory Management</title>

<style>
body{
    margin:0;
    font-family:'Segoe UI', sans-serif;
    background:#f7f3ee;
    color:#2b1d16;
}

.layout{
    display:flex;
    min-height:100vh;
}

.sidebar{
    width:260px;
    background:linear-gradient(180deg,#3b2f2f,#2a1f1b);
    color:#f5e6d3;
    padding:25px 20px;
}

.sidebar h2{
    text-align:center;
    margin-bottom:30px;
}

.sidebar a{
    display:block;
    padding:12px;
    margin-bottom:10px;
    color:#e8d5c0;
    text-decoration:none;
    border-radius:10px;
}

.sidebar a:hover{
    background:#5a3e36;
}

.main{
    flex:1;
    padding:30px;
}

.card-box{
    background:white;
    border-radius:18px;
    padding:22px;
    margin-bottom:25px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
}

.form-grid{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(180px,1fr));
    gap:15px;
}

.form-control{
    width:100%;
    padding:12px;
    border-radius:10px;
    border:1px solid #ccc;
}

.btn{
    padding:10px 12px;
    border:none;
    border-radius:8px;
    cursor:pointer;
    font-size:12px;
    font-weight:bold;
}

.btn-dark{background:#3b2f2f;color:white;}
.btn-warning{background:#a67c52;color:white;}
.btn-danger{background:#b04a4a;color:white;}

.table-container{
    background:white;
    border-radius:18px;
    overflow:hidden;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
}

table{
    width:100%;
    border-collapse:collapse;
}

th{
    background:#3b2f2f;
    color:white;
    padding:14px;
}

td{
    padding:12px;
    text-align:center;
    border-bottom:1px solid #eee;
}

.low-stock{color:#c62828;font-weight:bold;}
.ok-stock{color:#2e7d32;font-weight:bold;}
.expired{color:#c62828;font-weight:bold;}
.expiring{color:#ef6c00;font-weight:bold;}

.action-group{
    display:flex;
    flex-wrap:wrap;
    justify-content:center;
    gap:5px;
}

.action-group form{
    display:flex;
    gap:5px;
    align-items:center;
}

.small-input{
    width:70px;
    padding:8px;
    border-radius:8px;
    border:1px solid #ccc;
}
</style>
</head>

<body>

<div class="layout">

<div class="sidebar">

    <h2>☕ CoffeeBytes</h2>

    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="products.php">📦 Products</a>
    <a href="orders.php">🛒 Orders</a>
    <a href="recipes.php">🍹 Recipes</a>
    <a href="reports.php">📊 Reports</a>

    <?php if ($_SESSION['role'] == 'admin'): ?>
        <a href="users.php">👥 Users</a>
        <a href="logs.php">📜 Activity Logs</a>
    <?php endif; ?>

    <a href="inventory.php">🧪 Inventory</a>

</div>

<div class="main">

<h1>🧪 Inventory Management</h1>

<div class="card-box">

<form method="GET" style="display:flex; gap:10px; align-items:center;">

    <input
        type="text"
        name="search"
        class="form-control"
        placeholder="Search ingredient..."
        value="<?= htmlspecialchars($search) ?>"
    >

    <button type="submit" class="btn btn-dark">
        Search
    </button>

</form>

</div>

<div class="card-box">

<form method="POST" class="form-grid">

    <input type="text" name="name" class="form-control" placeholder="Ingredient Name" required>

    <input type="number" step="0.01" name="stock" class="form-control" placeholder="Stock" required>

    <input type="number" step="0.01" name="min" class="form-control" placeholder="Minimum Stock" required>

    <select name="unit" class="form-control" required>
        <option value="ml">mL</option>
        <option value="g">g</option>
    </select>

    <input type="date" name="expiration_date" class="form-control" required>

    <button type="submit" name="add" class="btn btn-dark">
        Add Ingredient
    </button>

</form>

</div>

<div class="table-container">

<table>

<tr>
    <th>Ingredient</th>
    <th>Stock</th>
    <th>Minimum</th>
    <th>Exp Date</th>
    <th>Status</th>
    <th>Actions</th>
</tr>

<?php while($row = $result->fetch_assoc()): ?>

<?php
$isLow = $row['stock'] <= $row['min_stock_ml'];
$today = date('Y-m-d');

$isExpired = $row['expiration_date'] < $today;
$expiringSoon = $row['expiration_date'] <= date('Y-m-d', strtotime('+7 days'));
?>

<tr>

<td><?= htmlspecialchars($row['name']) ?></td>
<td><?= $row['stock'] . " " . $row['unit'] ?></td>
<td><?= $row['min_stock_ml'] . " " . $row['unit'] ?></td>
<td><?= $row['expiration_date'] ?></td>

<td class="<?= $isExpired ? 'expired' : ($expiringSoon ? 'expiring' : ($isLow ? 'low-stock' : 'ok-stock')) ?>">
<?= $isExpired ? 'EXPIRED' : ($expiringSoon ? 'EXPIRING' : ($isLow ? 'LOW STOCK' : 'OK')) ?>
</td>

<td>

<div class="action-group">

<form method="POST">
    <input type="hidden" name="id" value="<?= $row['ingredient_id'] ?>">
    <input type="number" step="0.01" name="amount" class="small-input" required>
    <input type="date" name="expiration_date" class="small-input" required>
    <button type="submit" name="restock" class="btn btn-warning">Restock</button>
</form>

<form method="POST">
    <input type="hidden" name="id" value="<?= $row['ingredient_id'] ?>">
    <input type="number" step="0.01" name="amount" class="small-input" required>
    <button type="submit" name="deduct" class="btn btn-dark">Deduct</button>
</form>

<form method="POST" onsubmit="return confirm('Delete this ingredient?')">
    <input type="hidden" name="id" value="<?= $row['ingredient_id'] ?>">
    <button type="submit" name="delete" class="btn btn-danger">Delete</button>
</form>

</div>

</td>

</tr>

<?php endwhile; ?>

</table>

</div>

</div>

</div>

</body>
</html>