<?php
session_start();

include("../includes/functions.php");
include("../config/db.php");
// ADD PRODUCT
if (isset($_POST['add'])) {
    $stmt = $conn->prepare("
        INSERT INTO products(name, category, price)
        VALUES (?, ?, ?)
    ");
    $stmt->bind_param("ssd", $_POST['name'], $_POST['category'], $_POST['price']);
    $stmt->execute();
}

// DELETE PRODUCT
if (isset($_POST['delete'])) {
    $stmt = $conn->prepare("
        DELETE FROM products WHERE product_id=?
    ");
    $stmt->bind_param("i", $_POST['product_id']);
    $stmt->execute();
}

// UPDATE PRODUCT
if (isset($_POST['update'])) {
    $stmt = $conn->prepare("
        UPDATE products 
        SET name=?, category=?, price=? 
        WHERE product_id=?
    ");
    $stmt->bind_param(
        "ssdi",
        $_POST['name'],
        $_POST['category'],
        $_POST['price'],
        $_POST['product_id']
    );
    $stmt->execute();
}

// SEARCH
$search = $_GET['search'] ?? "";

if ($search != "") {
    $stmt = $conn->prepare("
        SELECT * FROM products 
        WHERE name LIKE ?
    ");
    $like = "%$search%";
    $stmt->bind_param("s", $like);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query("SELECT * FROM products");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Products - Coffee Shop Admin</title>

    <style>

        body{
            margin:0;
            font-family:'Segoe UI', sans-serif;
            background:#f7f3ee;
            color:#2b1d16;
        }

        .layout{
            display:flex;
            min-height:100vh;
        }

        /* SIDEBAR */

        .sidebar{
            width:260px;
            background:linear-gradient(180deg,#3b2f2f,#2a1f1b);
            color:#f5e6d3;
            padding:25px 20px;
            position:sticky;
            top:0;
        }

        .sidebar h2{
            text-align:center;
            margin-bottom:30px;
            font-size:26px;
        }

        .sidebar a{
            display:block;
            padding:12px 14px;
            margin-bottom:10px;
            color:#e8d5c0;
            text-decoration:none;
            border-radius:10px;
            transition:0.2s;
        }

        .sidebar a:hover{
            background:#5a3e36;
            color:#fff;
            transform:translateX(5px);
        }

        /* MAIN */

        .main{
            flex:1;
            padding:30px;
        }

        .header{
            display:flex;
            justify-content:space-between;
            align-items:center;
            margin-bottom:25px;
        }

        .header h1{
            margin:0;
            font-size:32px;
            color:#3b2f2f;
        }

        .back-btn{
            background:#5a3e36;
            color:white;
            padding:10px 16px;
            border-radius:10px;
            text-decoration:none;
            transition:0.2s;
        }

        .back-btn:hover{
            background:#3b2f2f;
        }

        /* SEARCH + FORM */

        .search-box,
        .form-control{
            width:100%;
            padding:12px;
            border-radius:10px;
            border:1px solid #d8c3b0;
            background:white;
            box-sizing:border-box;
        }

        .search-form{
            margin-bottom:20px;
        }

        .add-form{
            display:grid;
            grid-template-columns:repeat(auto-fit,minmax(200px,1fr));
            gap:15px;
            margin-bottom:25px;
        }

        .btn{
            padding:12px;
            border:none;
            border-radius:10px;
            cursor:pointer;
            font-weight:bold;
            transition:0.2s;
        }

        .btn-dark{
            background:#3b2f2f;
            color:white;
        }

        .btn-dark:hover{
            background:#2a1f1b;
        }

        .btn-primary{
            background:#a67c52;
            color:white;
        }

        .btn-primary:hover{
            background:#8b6543;
        }

        .btn-danger{
            background:#b04a4a;
            color:white;
        }

        .btn-danger:hover{
            background:#8e3636;
        }

        /* TABLE */

        .table-container{
            background:white;
            border-radius:18px;
            overflow:hidden;
            box-shadow:0 10px 25px rgba(0,0,0,0.08);
        }

        table{
            width:100%;
            border-collapse:collapse;
        }

        th{
            background:#3b2f2f;
            color:white;
            padding:16px;
            text-align:left;
        }

        td{
            padding:14px;
            border-bottom:1px solid #eee;
        }

        tr:hover{
            background:#faf7f3;
        }

        .action-buttons{
            display:flex;
            gap:8px;
        }

        @media(max-width:768px){

            .layout{
                flex-direction:column;
            }

            .sidebar{
                width:100%;
                text-align:center;
            }

            .header{
                flex-direction:column;
                gap:15px;
                align-items:flex-start;
            }

            .action-buttons{
                flex-direction:column;
            }
        }

    </style>

</head>

<body>

<div class="layout">

    <!-- SIDEBAR -->

    <div class="sidebar">

        <h2>☕ CoffeeBytes</h2>

        <a href="dashboard.php">🏠 Dashboard</a>
        <a href="products.php">📦 Products</a>
        <a href="orders.php">🛒 Orders</a>
        <a href="recipes.php">🍹 Recipes</a>
        <a href="reports.php">📊 Reports</a>
        <?php if (in_array($_SESSION['role'], ['admin', 'superuser'])): ?>
<a href="users.php">👥 Users</a>
<a href="logs.php">📜 Activity Logs</a>
<?php endif; ?>
        <a href="inventory.php">🧪 Inventory</a>

    </div>

    <!-- MAIN -->

    <div class="main">

        <div class="header">

            <h1>📦 Products Management</h1>

            <?php
$dashboard_link = ($_SESSION['role'] === 'staff')
    ? "../staff/staff_dashboard.php"
    : "dashboard.php";
?>

<a href="<?= $dashboard_link ?>" class="back-btn">
    ← Back to Dashboard
</a>

        </div>

        <!-- SEARCH -->

        <form method="GET" class="search-form">

            <input 
                class="search-box"
                name="search"
                placeholder="Search product..."
                value="<?= htmlspecialchars($search) ?>">

        </form>

        <!-- ADD PRODUCT -->

        <form method="POST" class="add-form">

            <input 
                class="form-control"
                name="name"
                placeholder="Product Name"
                required>

            <input 
                class="form-control"
                name="category"
                placeholder="Category"
                required>

            <input 
                class="form-control"
                name="price"
                placeholder="Price"
                required>

            <button class="btn btn-dark" name="add">
                Add Product
            </button>

        </form>

        <!-- PRODUCTS TABLE -->

        <div class="table-container">

            <table>

                <tr>
                    <th>Name</th>
                    <th>Category</th>
                    <th>Price</th>
                    <th>Action</th>
                </tr>

                <?php while ($row = $result->fetch_assoc()): ?>

                <tr>

                    <form method="POST">

                        <td>
                            <input 
                                class="form-control"
                                name="name"
                                value="<?= htmlspecialchars($row['name']) ?>">
                        </td>

                        <td>
                            <input 
                                class="form-control"
                                name="category"
                                value="<?= htmlspecialchars($row['category']) ?>">
                        </td>

                        <td>
                            <input 
                                class="form-control"
                                name="price"
                                value="<?= $row['price'] ?>">
                        </td>

                        <td>

                            <div class="action-buttons">

                                <input 
                                    type="hidden"
                                    name="product_id"
                                    value="<?= $row['product_id'] ?>">

                                <button 
                                    class="btn btn-primary"
                                    name="update">

                                    Save

                                </button>

                                <button 
                                    class="btn btn-danger"
                                    name="delete"
                                    onclick="return confirm('Delete this product?')">

                                    Delete

                                </button>

                            </div>

                        </td>

                    </form>

                </tr>

                <?php endwhile; ?>

            </table>

        </div>

    </div>

</div>

</body>
</html>