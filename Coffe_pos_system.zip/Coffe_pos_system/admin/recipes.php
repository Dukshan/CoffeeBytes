<?php
session_start();

include("../includes/functions.php");
include("../config/db.php");

/* =========================
   ADD RECIPE ITEM
========================= */
if(isset($_POST['add_recipe'])){

    $product_id    = $_POST['product_id'];
    $ingredient_id = $_POST['ingredient_id'];
    $amount        = $_POST['amount'];

    $stmt = $conn->prepare("
        INSERT INTO recipes (product_id, ingredient_id, amount_ml)
        VALUES (?, ?, ?)
    ");

    $stmt->bind_param("iid", $product_id, $ingredient_id, $amount);
    $stmt->execute();
}

/* =========================
   DELETE RECIPE ITEM
========================= */
if(isset($_POST['delete_recipe'])){

    $id = $_POST['recipe_id'];

    $stmt = $conn->prepare("
        DELETE FROM recipes WHERE recipe_id = ?
    ");

    $stmt->bind_param("i", $id);
    $stmt->execute();
}

/* =========================
   EDIT RECIPE ITEM
========================= */
if(isset($_POST['edit_recipe'])){

    $recipe_id = $_POST['recipe_id'];
    $amount    = $_POST['amount'];

    $stmt = $conn->prepare("
        UPDATE recipes
        SET amount_ml = ?
        WHERE recipe_id = ?
    ");

    $stmt->bind_param("di", $amount, $recipe_id);
    $stmt->execute();
}

/* =========================
   SEARCH
========================= */
$search = isset($_GET['search'])
    ? trim($_GET['search'])
    : '';

/* =========================
   PRODUCTS
========================= */
if($search != ''){

    $stmt = $conn->prepare("
        SELECT product_id AS id, name AS product_name
        FROM products
        WHERE name LIKE ?
    ");

    $search_term = "%{$search}%";

    $stmt->bind_param("s", $search_term);
    $stmt->execute();

    $products = $stmt->get_result();

}else{

    $products = $conn->query("
        SELECT product_id AS id, name AS product_name
        FROM products
    ");
}

/* =========================
   SELECTED PRODUCT
========================= */
$selected_product = isset($_GET['product_id'])
    ? (int)$_GET['product_id']
    : 0;

/* =========================
   RECIPE
========================= */
$recipe = null;

if($selected_product > 0){

    $recipe = $conn->query("
        SELECT
            r.recipe_id,
            r.amount_ml,
            i.name AS ingredient_name,
            i.unit AS unit
        FROM recipes r
        JOIN ingredients i
            ON r.ingredient_id = i.ingredient_id
        WHERE r.product_id = $selected_product
    ");

    if(!$recipe){
        die("Recipe Query Failed: " . $conn->error);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Recipe Management</title>

<style>

body{
    margin:0;
    font-family:'Segoe UI',sans-serif;
    background:#f7f3ee;
    color:#2b1d16;
}

.layout{
    display:flex;
    min-height:100vh;
}

/* SIDEBAR */

.sidebar{
    width:260px;
    background:linear-gradient(180deg,#3b2f2f,#2a1f1b);
    color:#f5e6d3;
    padding:25px 20px;
}

.sidebar h2{
    text-align:center;
    margin-bottom:30px;
}

.sidebar a{
    display:block;
    padding:12px;
    margin-bottom:10px;
    color:#e8d5c0;
    text-decoration:none;
    border-radius:10px;
}

.sidebar a:hover{
    background:#5a3e36;
}

/* MAIN */

.main{
    flex:1;
    padding:30px;
}

.header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:25px;
}

.back-btn{
    background:#5a3e36;
    color:white;
    padding:10px 14px;
    border-radius:10px;
    text-decoration:none;
}

/* SEARCH */

.search-box{
    background:white;
    padding:20px;
    border-radius:15px;
    margin-bottom:20px;
}

/* PRODUCTS */

.products-grid{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(180px,1fr));
    gap:15px;
    margin-bottom:25px;
}

.product-card{
    background:white;
    padding:20px;
    text-align:center;
    border-radius:15px;
    text-decoration:none;
    color:#2b1d16;
    border:2px solid transparent;
    transition:0.2s;
}

.product-card:hover{
    transform:translateY(-3px);
}

.active-card{
    border:2px solid #6f4e37;
    background:#f5ebe1;
}

/* CARD */

.card-box{
    background:white;
    padding:20px;
    border-radius:15px;
    margin-bottom:20px;
}

.form-grid{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(180px,1fr));
    gap:10px;
    align-items:center;
}

.form-control{
    width:100%;
    padding:10px;
    border-radius:8px;
    border:1px solid #ccc;
    box-sizing:border-box;
}

/* BUTTONS */

.btn{
    padding:10px;
    border:none;
    border-radius:8px;
    cursor:pointer;
    font-weight:bold;
}

.btn-dark{
    background:#3b2f2f;
    color:white;
}

.btn-danger{
    background:#b04a4a;
    color:white;
}

/* TABLE */

.recipe-table{
    width:100%;
    border-collapse:collapse;
    background:white;
    border-radius:15px;
    overflow:hidden;
}

.recipe-table th{
    background:#3b2f2f;
    color:white;
    padding:14px;
    text-align:center;
}

.recipe-table td{
    padding:14px;
    text-align:center;
    vertical-align:middle;
    border-bottom:1px solid #eee;
}

/* ACTIONS */

.action-cell{
    width:260px;
    vertical-align:middle;
}

.action-wrapper{
    display:flex;
    flex-direction:column;
    align-items:center;
    justify-content:center;
    gap:6px;
}

.action-group{
    display:flex;
    align-items:center;
    justify-content:center;
    gap:8px;
}

.action-input{
    width:80px;
    height:32px;
    text-align:center;
    border:1px solid #ccc;
    border-radius:6px;
    box-sizing:border-box;
}

.action-group button{
    height:32px;
    padding:0 10px;
    display:flex;
    align-items:center;
    justify-content:center;
    line-height:1;
}

</style>

</head>

<body>

<div class="layout">

<!-- SIDEBAR -->
<div class="sidebar">

    <h2>☕ CoffeeBytes</h2>

    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="products.php">📦 Products</a>
    <a href="orders.php">🛒 Orders</a>
    <a href="recipes.php">🍹 Recipes</a>
    <a href="reports.php">📊 Reports</a>

   <?php if (in_array($_SESSION['role'], ['admin', 'superuser'])): ?>
        <a href="users.php">👥 Users</a>
        <a href="logs.php">📜 Activity Logs</a>
    <?php endif; ?>

    <a href="inventory.php">🧪 Inventory</a>

</div>

<!-- MAIN -->
<div class="main">

    <!-- HEADER -->
    <div class="header">

        <h1>🍹 Recipe Management</h1>

        <?php
        $dashboard_link = ($_SESSION['role'] === 'staff')
            ? "../staff/staff_dashboard.php"
            : "dashboard.php";
        ?>

        <a href="<?= $dashboard_link ?>" class="back-btn">
            ← Back to Dashboard
        </a>

    </div>

    <!-- SEARCH -->
    <div class="search-box">

        <form method="GET">

            <input type="text"
                   name="search"
                   class="form-control"
                   placeholder="🔍 Search product recipe..."
                   value="<?= htmlspecialchars($search) ?>">

        </form>

    </div>

    <!-- PRODUCTS -->
    <div class="products-grid">

        <?php while($p = $products->fetch_assoc()): ?>

        <a href="recipes.php?product_id=<?= $p['id'] ?>&search=<?= urlencode($search) ?>"
           class="product-card <?= $selected_product == $p['id'] ? 'active-card' : '' ?>">

            ☕ <br><br>

            <?= $p['product_name'] ?>

        </a>

        <?php endwhile; ?>

    </div>

<?php if($selected_product): ?>

<!-- ADD RECIPE -->
<div class="card-box">

<form method="POST" class="form-grid">

    <input type="hidden"
           name="product_id"
           value="<?= $selected_product ?>">

    <select name="ingredient_id"
            class="form-control"
            required>

        <option value="">Select Ingredient</option>

        <?php
        $ingredients = $conn->query("
            SELECT ingredient_id, name, unit
            FROM ingredients
        ");

        while($i = $ingredients->fetch_assoc()):
        ?>

        <option value="<?= $i['ingredient_id'] ?>">
            <?= $i['name'] ?> (<?= $i['unit'] ?>)
        </option>

        <?php endwhile; ?>

    </select>

    <input type="number"
           step="0.01"
           name="amount"
           class="form-control"
           placeholder="Amount"
           required>

    <button class="btn btn-dark" name="add_recipe">
        Add
    </button>

</form>

</div>

<!-- TABLE -->
<table class="recipe-table">

<tr>
    <th>Ingredient</th>
    <th>Amount</th>
    <th>Action</th>
</tr>

<?php if($recipe && $recipe->num_rows > 0): ?>

<?php while($row = $recipe->fetch_assoc()): ?>

<tr>

<td><?= $row['ingredient_name'] ?></td>

<td>
    <?= $row['amount_ml'] . " " . $row['unit'] ?>
</td>

<td class="action-cell">

<div class="action-wrapper">

    <!-- UPDATE -->
    <form method="POST" class="action-group">

        <input type="hidden"
               name="recipe_id"
               value="<?= $row['recipe_id'] ?>">

        <input type="number"
               step="0.01"
               name="amount"
               value="<?= $row['amount_ml'] ?>"
               class="action-input">

        <button class="btn btn-dark"
                name="edit_recipe">

            Update

        </button>

    </form>

    <!-- DELETE -->
    <form method="POST" class="action-group">

        <input type="hidden"
               name="recipe_id"
               value="<?= $row['recipe_id'] ?>">

        <button class="btn btn-danger"
                name="delete_recipe"
                onclick="return confirm('Delete item?')">

            Delete

        </button>

    </form>

</div>

</td>

</tr>

<?php endwhile; ?>

<?php else: ?>

<tr>
    <td colspan="3">No recipe found</td>
</tr>

<?php endif; ?>

</table>

<?php endif; ?>

</div>
</div>

</body>
</html>