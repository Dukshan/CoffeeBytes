<?php
session_start();

include("../includes/functions.php");
include("../config/db.php");

/* =========================
   ACCESS CONTROL
========================= */
if (!isset($_SESSION['role'])) {
    header("Location: ../index.php");
    exit();
}

$today = date("Y-m-d");

/* =========================
   SAFE QUERY FUNCTION
========================= */
function runQuery($conn, $sql, $errorLabel) {
    $result = $conn->query($sql);
    if (!$result) {
        die($errorLabel . ": " . $conn->error);
    }
    return $result;
}

/* =========================
   SALES TODAY (FIXED: ONLY COMPLETED)
========================= */
$salesQuery = runQuery($conn, "
    SELECT SUM(total) AS total_sales
    FROM orders
    WHERE DATE(created_at) = '$today'
    AND status = 'Completed'
", "Sales Query Failed");

$totalSales = $salesQuery->fetch_assoc()['total_sales'] ?? 0;

/* =========================
   ORDERS TODAY
========================= */
$orderQuery = runQuery($conn, "
    SELECT COUNT(*) AS total_orders
    FROM orders
    WHERE DATE(created_at) = '$today'
", "Orders Query Failed");

$totalOrders = $orderQuery->fetch_assoc()['total_orders'] ?? 0;

/* =========================
   LOW STOCK
========================= */
$stockQuery = runQuery($conn, "
    SELECT COUNT(*) AS low_stock_count
    FROM ingredients
    WHERE stock <= min_stock_ml
", "Stock Query Failed");

$lowStock = $stockQuery->fetch_assoc()['low_stock_count'] ?? 0;

/* =========================
   EXPIRING SOON
========================= */
$expiringQuery = runQuery($conn, "
    SELECT ingredient_id, name, stock, unit, expiration_date
    FROM ingredients
    WHERE expiration_date IS NOT NULL
    AND expiration_date BETWEEN CURDATE()
    AND DATE_ADD(CURDATE(), INTERVAL 7 DAY)
    ORDER BY expiration_date ASC
    LIMIT 5
", "Expiring Query Failed");

$expiringCount = $expiringQuery->num_rows;
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>CoffeeBytes Dashboard</title>

<style>

body{
    margin:0;
    font-family:'Segoe UI', sans-serif;
    background:#f7f3ee;
    color:#2b1d16;
}

.layout{
    display:flex;
    min-height:100vh;
}

/* SIDEBAR FIXED LAYOUT */
.sidebar{
    width:260px;
    background:linear-gradient(180deg,#3b2f2f,#2a1f1b);
    color:#f5e6d3;
    padding:25px 20px;

    display:flex;
    flex-direction:column;
    height:100vh;
}

.sidebar h2{
    text-align:center;
    margin-bottom:30px;
}

.sidebar a{
    display:block;
    padding:12px;
    margin-bottom:10px;
    color:#e8d5c0;
    text-decoration:none;
    border-radius:10px;
}

.sidebar a:hover{
    background:#5a3e36;
}

/* pushes logout down */
.sidebar a.logout-btn{
    margin-top:auto;
    background:#b04a4a;
    color:white;
    font-weight:bold;
    text-align:center;
}

.sidebar a.logout-btn:hover{
    background:#8e3636;
}

.main{
    flex:1;
    padding:30px;
}

.header{
    display:flex;
    justify-content:space-between;
    align-items:center;
}

.date-badge{
    background:#fff;
    padding:8px 14px;
    border-radius:20px;
    border:1px solid #ddd;
}

.pos-button{
    display:inline-block;
    margin:15px 0 25px 0;
    padding:12px 18px;
    background:#3b2f2f;
    color:white;
    text-decoration:none;
    border-radius:12px;
    font-weight:bold;
}

.cards{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(240px,1fr));
    gap:20px;
    margin-top:15px;
}

.card{
    padding:22px;
    border-radius:18px;
    color:#fff;
}

.sales{background:#4b2e2b;}
.orders{background:#a67c52;}
.stock{background:#5a3e36;}

.exp-box{
    margin-top:30px;
    background:white;
    border-radius:18px;
    padding:20px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
}

.exp-table{
    width:100%;
    border-collapse:collapse;
}

.exp-table th{
    background:#3b2f2f;
    color:white;
    padding:12px;
    text-align:center;
}

.exp-table td{
    padding:12px;
    border-bottom:1px solid #eee;
    text-align:center;
}

.warning{color:#ef6c00;font-weight:bold;}
.good{color:#2e7d32;font-weight:bold;}

</style>
</head>

<body>

<div class="layout">

<div class="sidebar">
    <h2>☕ CoffeeBytes</h2>

    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="products.php">📦 Products</a>
    <a href="orders.php">🛒 Orders</a>
    <a href="recipes.php">🍹 Recipes</a>
    <a href="reports.php">📊 Reports</a>

    <?php if (in_array($_SESSION['role'], ['admin', 'superuser'])): ?>
        <a href="users.php">👥 Users</a>
        <a href="logs.php">📜 Activity Logs</a>
    <?php endif; ?>

    <a href="inventory.php">🧪 Inventory</a>

    <!-- FIXED LOGOUT -->
    <a href="../auth/logout.php" class="logout-btn">🚪 Logout</a>
</div>

<div class="main">

    <div class="header">
        <h1>Dashboard Overview</h1>
        <div class="date-badge">📅 <?= $today ?></div>
    </div>

    <a href="../staff/pos.php" class="pos-button">
        🧾 Open POS System
    </a>

    <div class="cards">

        <div class="card sales">
            <h3>Total Sales Today</h3>
            <h2>₱<?= number_format($totalSales, 2) ?></h2>
        </div>

        <div class="card orders">
            <h3>Orders Today</h3>
            <h2><?= $totalOrders ?></h2>
        </div>

        <div class="card stock">
            <h3>Low Stock Ingredients</h3>
            <h2><?= $lowStock ?></h2>
        </div>

    </div>

    <div class="exp-box">

        <h3>⚠️ Expiring Soon Ingredients (7 Days)</h3>
        <p><?= $expiringCount ?> item(s) need attention</p>

        <table class="exp-table">

            <tr>
                <th>Ingredient</th>
                <th>Stock</th>
                <th>Expiration Date</th>
            </tr>

            <?php if($expiringCount > 0): ?>
                <?php while($row = $expiringQuery->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['name']) ?></td>
                    <td><?= $row['stock'] . " " . $row['unit'] ?></td>
                    <td class="warning"><?= $row['expiration_date'] ?></td>
                </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="3" class="good">✔ No ingredients expiring soon</td>
                </tr>
            <?php endif; ?>

        </table>

    </div>

</div>

</div>

</body>
</html>