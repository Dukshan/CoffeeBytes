<?php
session_start();
include("../config/db.php");

if (!isset($_SESSION['role'])) {
    header("Location: ../index.php");
    exit();
}

$role = $_SESSION['role'];

$dashboard_link = ($role === 'staff')
    ? "../staff/staff_dashboard.php"
    : "dashboard.php";

/* =========================
   FILTER VALUES
========================= */
$user_filter = $_GET['user'] ?? '';
$action_filter = $_GET['action'] ?? '';
$from_date = $_GET['from'] ?? '';
$to_date = $_GET['to'] ?? '';

/* =========================
   BUILD QUERY DYNAMICALLY
========================= */
$where = "WHERE 1=1";

if (!empty($user_filter)) {
    $user_filter = $conn->real_escape_string($user_filter);
    $where .= " AND u.name LIKE '%$user_filter%'";
}

if (!empty($action_filter)) {
    $action_filter = $conn->real_escape_string($action_filter);
    $where .= " AND l.action LIKE '%$action_filter%'";
}

if (!empty($from_date)) {
    $where .= " AND DATE(l.created_at) >= '$from_date'";
}

if (!empty($to_date)) {
    $where .= " AND DATE(l.created_at) <= '$to_date'";
}

/* =========================
   FETCH LOGS
========================= */
$logs = $conn->query("
    SELECT 
        l.log_id,
        l.action,
        l.details,
        l.created_at,
        u.name AS user_name
    FROM logs l
    LEFT JOIN users u ON l.user_id = u.user_id
    $where
    ORDER BY l.created_at DESC
");

if (!$logs) {
    die("Logs Query Failed: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Activity Logs - CoffeeBytes</title>

<style>

body{
    margin:0;
    font-family:'Segoe UI', sans-serif;
    background:#f7f3ee;
    color:#2b1d16;
}

.layout{
    display:flex;
    min-height:100vh;
}

/* SIDEBAR */
.sidebar{
    width:260px;
    background:linear-gradient(180deg,#3b2f2f,#2a1f1b);
    color:#f5e6d3;
    padding:25px 20px;
}

.sidebar h2{
    text-align:center;
    margin-bottom:30px;
    color:#fff;
}

.sidebar a{
    display:block;
    padding:12px;
    margin-bottom:10px;
    color:#e8d5c0;
    text-decoration:none;
    border-radius:10px;
}

.sidebar a:hover{
    background:#5a3e36;
}

/* MAIN */
.main{
    flex:1;
    padding:30px;
}

/* BACK BUTTON */
.back-btn{
    display:inline-block;
    padding:10px 15px;
    background:#3b2f2f;
    color:white;
    border-radius:10px;
    text-decoration:none;
    margin-bottom:15px;
    font-weight:600;
}

/* FILTER BOX */
.filter-box{
    background:#fff;
    padding:15px;
    border-radius:12px;
    margin-bottom:20px;
    box-shadow:0 6px 15px rgba(0,0,0,0.08);
    display:flex;
    gap:10px;
    flex-wrap:wrap;
}

.filter-box input{
    padding:8px;
    border:1px solid #ddd;
    border-radius:8px;
}

.filter-box button{
    padding:8px 12px;
    background:#3b2f2f;
    color:white;
    border:none;
    border-radius:8px;
    cursor:pointer;
}

.log-box{
    background:white;
    padding:20px;
    border-radius:16px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
}

table{
    width:100%;
    border-collapse:collapse;
}

th{
    background:#3b2f2f;
    color:white;
    padding:12px;
    text-align:left;
}

td{
    padding:12px;
    border-bottom:1px solid #eee;
}

</style>
</head>

<body>

<div class="layout">

<!-- SIDEBAR -->
<div class="sidebar">

    <h2>☕ CoffeeBytes</h2>

    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="products.php">📦 Products</a>
    <a href="orders.php">🛒 Orders</a>
    <a href="recipes.php">🍹 Recipes</a>
    <a href="reports.php">📊 Reports</a>

    <?php if($role === 'admin'): ?>
        <a href="users.php">👥 Users</a>
        <a href="logs.php">📜 Activity Logs</a>
    <?php endif; ?>

    <a href="inventory.php">🧪 Inventory</a>
    

</div>

<!-- MAIN -->
<div class="main">

<a href="<?= $dashboard_link ?>" class="back-btn">← Back to Dashboard</a>

<h2>📜 Activity Logs</h2>

<!-- FILTERS -->
<form method="GET" class="filter-box">

    <input type="text" name="user" placeholder="Filter by user" value="<?= $user_filter ?>">

    <input type="text" name="action" placeholder="Filter by action" value="<?= $action_filter ?>">

    <input type="date" name="from" value="<?= $from_date ?>">

    <input type="date" name="to" value="<?= $to_date ?>">

    <button type="submit">Filter</button>

    <a href="logs.php" style="padding:8px 12px;background:#a67c52;color:white;border-radius:8px;text-decoration:none;">
        Reset
    </a>

</form>

<!-- LOG TABLE -->
<div class="log-box">

<table>

<tr>
    <th>User</th>
    <th>Action</th>
    <th>Details</th>
    <th>Date</th>
</tr>

<?php if($logs && $logs->num_rows > 0): ?>

    <?php while($l = $logs->fetch_assoc()): ?>
    <tr>
        <td><?= htmlspecialchars($l['user_name'] ?? 'System') ?></td>
        <td><?= htmlspecialchars($l['action']) ?></td>
        <td><?= htmlspecialchars($l['details']) ?></td>
        <td><?= $l['created_at'] ?></td>
    </tr>
    <?php endwhile; ?>

<?php else: ?>
<tr>
    <td colspan="4">No logs found</td>
</tr>
<?php endif; ?>

</table>

</div>

</div>

</div>

</body>
</html>