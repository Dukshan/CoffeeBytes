<?php
session_start();

include("../includes/functions.php");
include("../config/db.php");

/* =========================
   DELETE SALES RECORD
========================= */
if(isset($_POST['delete_sale'])){

    $sale_date = $_POST['sale_date'];

    $stmt = $conn->prepare("
        DELETE FROM orders
        WHERE DATE(created_at) = ?
    ");

    $stmt->bind_param("s", $sale_date);
    $stmt->execute();
}

/* =========================
   SALES DATA
========================= */
$data = $conn->query("
    SELECT 
        DATE(created_at) AS date,
        COUNT(order_id) AS total_orders,
        SUM(total) AS total_sales
    FROM orders
    GROUP BY DATE(created_at)
    ORDER BY DATE(created_at) DESC
");

/* =========================
   CHART DATA
========================= */
$chart_labels = [];
$chart_totals = [];

$data->data_seek(0);

while($row = $data->fetch_assoc()){

    $chart_labels[] = $row['date'];
    $chart_totals[] = $row['total_sales'];
}

$data->data_seek(0);
?>

<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<title>Sales Reports</title>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>

body{
    margin:0;
    font-family:'Segoe UI', sans-serif;
    background:#f7f3ee;
    color:#2b1d16;
}

.layout{
    display:flex;
    min-height:100vh;
}

/* SIDEBAR */

.sidebar{
    width:260px;
    background:linear-gradient(180deg,#3b2f2f,#2a1f1b);
    color:#f5e6d3;
    padding:25px 20px;
    position:sticky;
    top:0;
}

.sidebar h2{
    text-align:center;
    margin-bottom:30px;
    font-size:26px;
}

.sidebar a{
    display:block;
    padding:12px 14px;
    margin-bottom:10px;
    color:#e8d5c0;
    text-decoration:none;
    border-radius:10px;
    transition:0.2s;
}

.sidebar a:hover{
    background:#5a3e36;
    color:#fff;
    transform:translateX(5px);
}

/* MAIN */

.main{
    flex:1;
    padding:30px;
}

.header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:25px;
}

.header h1{
    margin:0;
    font-size:32px;
    color:#3b2f2f;
}

.back-btn{
    background:#5a3e36;
    color:white;
    padding:10px 16px;
    border-radius:10px;
    text-decoration:none;
    transition:0.2s;
}

.back-btn:hover{
    background:#3b2f2f;
}

/* CARD */

.card-box{
    background:white;
    border-radius:18px;
    padding:25px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
    margin-bottom:25px;
}

/* CHART */

.chart-container{
    position:relative;
    width:100%;
    height:450px;
}

/* GRID */

.sales-grid{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(360px,1fr));
    gap:20px;
}

.sale-card{
    background:white;
    border-radius:18px;
    padding:20px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
}

.sale-date{
    font-size:24px;
    font-weight:bold;
    margin-bottom:15px;
    color:#3b2f2f;
}

.sale-info{
    margin-bottom:10px;
    font-size:16px;
}

.total-sales{
    font-size:30px;
    font-weight:bold;
    color:#6f4e37;
    margin:15px 0;
}

.section-title{
    margin-top:20px;
    margin-bottom:10px;
    font-size:18px;
    font-weight:bold;
    color:#3b2f2f;
}

.list-box{
    background:#f7f3ee;
    border-radius:12px;
    padding:12px;
    margin-bottom:12px;
}

.list-item{
    padding:8px 0;
    border-bottom:1px solid #ddd;
    font-size:15px;
}

.list-item:last-child{
    border-bottom:none;
}

.delete-btn{
    width:100%;
    padding:12px;
    border:none;
    border-radius:10px;
    background:#b04a4a;
    color:white;
    font-weight:bold;
    cursor:pointer;
    transition:0.2s;
    margin-top:15px;
}

.delete-btn:hover{
    background:#922f2f;
}

.no-data{
    text-align:center;
    padding:40px;
    background:white;
    border-radius:18px;
    font-size:18px;
}

@media(max-width:768px){

    .layout{
        flex-direction:column;
    }

    .sidebar{
        width:100%;
        text-align:center;
    }

    .header{
        flex-direction:column;
        align-items:flex-start;
        gap:15px;
    }

    .chart-container{
        height:320px;
    }
}

</style>

</head>

<body>

<div class="layout">

<!-- SIDEBAR -->

<div class="sidebar">

    <h2>☕ CoffeeBytes</h2>

    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="products.php">📦 Products</a>
    <a href="orders.php">🛒 Orders</a>
    <a href="recipes.php">🍹 Recipes</a>
    <a href="reports.php">📊 Reports</a>

   <?php if (in_array($_SESSION['role'], ['admin', 'superuser'])): ?>
        <a href="users.php">👥 Users</a>
        <a href="logs.php">📜 Activity Logs</a>
    <?php endif; ?>

    <a href="inventory.php">🧪 Inventory</a>

</div>

<!-- MAIN -->

<div class="main">

<div class="header">

    <h1>📊 Sales Reports</h1>

    <?php
    $dashboard_link = ($_SESSION['role'] === 'staff')
        ? "../staff/staff_dashboard.php"
        : "dashboard.php";
    ?>

    <a href="<?= $dashboard_link ?>" class="back-btn">
        ← Back to Dashboard
    </a>

</div>

<!-- CHART -->

<div class="card-box">

    <div class="chart-container">

        <canvas id="chart"></canvas>

    </div>

</div>

<!-- SALES GRID -->

<div class="sales-grid">

<?php if($data->num_rows > 0): ?>

<?php while($row = $data->fetch_assoc()): ?>

<?php

$sale_date = $row['date'];

/* =========================
   ITEMS ORDERED
========================= */

$items = $conn->query("
    SELECT
        p.name AS product_name,
        SUM(oi.quantity) AS qty
    FROM order_items oi

    JOIN orders o
        ON oi.order_id = o.order_id

    JOIN products p
        ON oi.product_id = p.product_id

    WHERE DATE(o.created_at) = '$sale_date'

    GROUP BY p.name
");

/* =========================
   INGREDIENTS USED
========================= */

$ingredients = $conn->query("
    SELECT
        i.name AS ingredient_name,
        i.unit,
        SUM(r.amount_ml * oi.quantity) AS total_used

    FROM order_items oi

    JOIN orders o
        ON oi.order_id = o.order_id

    JOIN products p
        ON oi.product_id = p.product_id

    JOIN recipes r
        ON p.product_id = r.product_id

    JOIN ingredients i
        ON r.ingredient_id = i.ingredient_id

    WHERE DATE(o.created_at) = '$sale_date'

    GROUP BY i.name, i.unit
");

?>

<div class="sale-card">

    <div class="sale-date">
        📅 <?= $sale_date ?>
    </div>

    <div class="sale-info">
        🛒 Orders:
        <strong><?= $row['total_orders'] ?></strong>
    </div>

    <div class="total-sales">
        ₱<?= number_format($row['total_sales'], 2) ?>
    </div>

    <!-- ITEMS ORDERED -->

    <div class="section-title">
        ☕ Items Ordered
    </div>

    <div class="list-box">

        <?php if($items && $items->num_rows > 0): ?>

            <?php while($item = $items->fetch_assoc()): ?>

            <div class="list-item">

                <?= $item['product_name'] ?>

                —
                <strong><?= $item['qty'] ?> sold</strong>

            </div>

            <?php endwhile; ?>

        <?php else: ?>

            <div class="list-item">
                No items found
            </div>

        <?php endif; ?>

    </div>

    <!-- INGREDIENTS USED -->

    <div class="section-title">
        🧪 Ingredients Used
    </div>

    <div class="list-box">

        <?php if($ingredients && $ingredients->num_rows > 0): ?>

            <?php while($ing = $ingredients->fetch_assoc()): ?>

            <div class="list-item">

                <?= $ing['ingredient_name'] ?>

                —
                <strong>

                    <?= number_format($ing['total_used'], 2) ?>
                    <?= $ing['unit'] ?>

                </strong>

            </div>

            <?php endwhile; ?>

        <?php else: ?>

            <div class="list-item">
                No ingredients found
            </div>

        <?php endif; ?>

    </div>

    <!-- DELETE -->

    <form method="POST">

        <input type="hidden"
               name="sale_date"
               value="<?= $sale_date ?>">

        <button type="submit"
                name="delete_sale"
                class="delete-btn"
                onclick="return confirm('Delete all sales records for this day?')">

            Delete Record

        </button>

    </form>

</div>

<?php endwhile; ?>

<?php else: ?>

<div class="no-data">
    No sales records found
</div>

<?php endif; ?>

</div>

</div>

</div>

<script>

const labels = <?= json_encode($chart_labels) ?>;

const salesData = <?= json_encode($chart_totals) ?>;

new Chart(document.getElementById('chart'), {

    type: 'bar',

    data: {

        labels: labels,

        datasets: [{

            label: 'Daily Sales',

            data: salesData,

            backgroundColor: '#6f4e37',

            borderRadius: 10

        }]

    },

    options: {

        responsive: true,

        plugins: {

            legend: {

                labels: {

                    color: '#3b2f2f',

                    font: {
                        size: 14
                    }

                }

            }

        },

        scales: {

            x: {

                ticks: {
                    color:'#5a3e36'
                },

                grid: {
                    display:false
                }

            },

            y: {

                beginAtZero:true,

                ticks: {
                    color:'#5a3e36'
                }

            }

        }

    }

});

</script>

</body>
</html>