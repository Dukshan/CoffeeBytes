<?php
session_start();

include("../includes/functions.php");
include("../config/db.php");

/* =========================
   ADMIN ONLY ACCESS
========================= */

if($_SESSION['role'] !== 'admin'){
    header("Location: ../staff/staff_dashboard.php");
    exit;
}

/* =========================
   ADD USER
========================= */

if (isset($_POST['add'])) {

    $name     = trim($_POST['name']);
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $role     = $_POST['role'];

    if ($name && $username && $password && $role) {

        $stmt = $conn->prepare("
            INSERT INTO users (name, username, password, role)
            VALUES (?, ?, MD5(?), ?)
        ");

        $stmt->bind_param(
            "ssss",
            $name,
            $username,
            $password,
            $role
        );

        $stmt->execute();
    }

    header("Location: users.php");
    exit();
}

/* =========================
   CHANGE PASSWORD
========================= */

if (isset($_POST['change_password'])) {

    $user_id = (int) $_POST['user_id'];
    $new_password = trim($_POST['new_password']);

    if (!empty($new_password)) {

        $stmt = $conn->prepare("
            UPDATE users
            SET password = MD5(?)
            WHERE user_id = ?
        ");

        $stmt->bind_param(
            "si",
            $new_password,
            $user_id
        );

        $stmt->execute();
    }

    header("Location: users.php");
    exit();
}

/* =========================
   DELETE USER
========================= */

if (isset($_GET['delete'])) {

    $id = (int) $_GET['delete'];

    $stmt = $conn->prepare("
        DELETE FROM users
        WHERE user_id = ?
    ");

    $stmt->bind_param("i", $id);
    $stmt->execute();

    header("Location: users.php");
    exit();
}

/* =========================
   FETCH USERS
========================= */

$result = $conn->query("
    SELECT * FROM users
    ORDER BY user_id DESC
");
?>

<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<title>User Management</title>

<style>

body{
    margin:0;
    font-family:'Segoe UI',sans-serif;
    background:#f7f3ee;
    color:#2b1d16;
}

.layout{
    display:flex;
    min-height:100vh;
}

/* SIDEBAR */

.sidebar{
    width:260px;
    background:linear-gradient(180deg,#3b2f2f,#2a1f1b);
    color:#f5e6d3;
    padding:25px 20px;
    position:sticky;
    top:0;
}

.sidebar h2{
    text-align:center;
    margin-bottom:30px;
    font-size:26px;
}

.sidebar a{
    display:block;
    padding:12px 14px;
    margin-bottom:10px;
    color:#e8d5c0;
    text-decoration:none;
    border-radius:10px;
    transition:0.2s;
}

.sidebar a:hover{
    background:#5a3e36;
    color:#fff;
    transform:translateX(5px);
}

/* MAIN */

.main{
    flex:1;
    padding:30px;
}

.header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:25px;
}

.header h1{
    margin:0;
    font-size:32px;
    color:#3b2f2f;
}

.back-btn{
    background:#5a3e36;
    color:white;
    padding:10px 16px;
    border-radius:10px;
    text-decoration:none;
    transition:0.2s;
}

.back-btn:hover{
    background:#3b2f2f;
}

/* CARD */

.card-box{
    background:white;
    border-radius:18px;
    padding:22px;
    margin-bottom:25px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
}

/* FORM */

.form-grid{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(180px,1fr));
    gap:15px;
}

.form-control{
    width:100%;
    padding:12px;
    border-radius:10px;
    border:1px solid #d8c3b0;
    box-sizing:border-box;
    background:white;
}

/* BUTTONS */

.btn{
    padding:10px 14px;
    border:none;
    border-radius:10px;
    cursor:pointer;
    font-weight:bold;
    transition:0.2s;
    text-decoration:none;
    display:inline-block;
    text-align:center;
}

.btn-dark{
    background:#3b2f2f;
    color:white;
}

.btn-dark:hover{
    background:#2a1f1b;
}

.btn-danger{
    background:#b04a4a;
    color:white;
}

.btn-danger:hover{
    background:#8e3636;
}

/* TABLE */

.table-container{
    background:white;
    border-radius:18px;
    overflow:hidden;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
}

table{
    width:100%;
    border-collapse:collapse;
}

th{
    background:#3b2f2f;
    color:white;
    padding:16px;
    text-align:center;
}

td{
    padding:16px;
    border-bottom:1px solid #eee;
    text-align:center;
}

tr:hover{
    background:#faf7f3;
}

.role-admin{
    color:#6f4e37;
    font-weight:bold;
}

.role-staff{
    color:#a67c52;
    font-weight:bold;
}

.empty-text{
    color:#999;
}

.password-form{
    display:flex;
    gap:8px;
    align-items:center;
    justify-content:center;
}

.password-input{
    max-width:160px;
}

@media(max-width:768px){

    .layout{
        flex-direction:column;
    }

    .sidebar{
        width:100%;
        text-align:center;
    }

    .header{
        flex-direction:column;
        align-items:flex-start;
        gap:15px;
    }

    .form-grid{
        grid-template-columns:1fr;
    }

    .password-form{
        flex-direction:column;
    }
}

</style>

</head>

<body>

<div class="layout">

<!-- SIDEBAR -->

<div class="sidebar">

    <h2>☕ CoffeeBytes</h2>

    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="products.php">📦 Products</a>
    <a href="orders.php">🛒 Orders</a>
    <a href="recipes.php">🍹 Recipes</a>
    <a href="reports.php">📊 Reports</a>
    <a href="users.php">👥 Users</a>
    <a href="logs.php">📜 Activity Logs</a>
    <a href="inventory.php">🧪 Inventory</a>

</div>

<!-- MAIN -->

<div class="main">

<div class="header">

    <h1>👥 User Management</h1>

    <a href="dashboard.php" class="back-btn">
        ← Back to Dashboard
    </a>

</div>

<!-- ADD USER -->

<div class="card-box">

<form method="POST" class="form-grid">

    <input
        type="text"
        name="name"
        class="form-control"
        placeholder="Full Name"
        required>

    <input
        type="text"
        name="username"
        class="form-control"
        placeholder="Username"
        required>

    <input
        type="password"
        name="password"
        class="form-control"
        placeholder="Password"
        required>

    <select
        name="role"
        class="form-control">

        <option value="admin">
            Admin
        </option>

        <option value="staff" selected>
            Staff
        </option>

    </select>

    <button
        type="submit"
        name="add"
        class="btn btn-dark">

        Add User

    </button>

</form>

</div>

<!-- USERS TABLE -->

<div class="table-container">

<table>

<thead>

<tr>
    <th>Name</th>
    <th>Username</th>
    <th>Role</th>
    <th>Change Password</th>
    <th>Action</th>
</tr>

</thead>

<tbody>

<?php while ($row = $result->fetch_assoc()): ?>

<tr>

<td>
    <?= htmlspecialchars($row['name']) ?>
</td>

<td>
    <?= htmlspecialchars($row['username']) ?>
</td>

<td class="<?= $row['role'] === 'admin' ? 'role-admin' : 'role-staff' ?>">

    <?= htmlspecialchars($row['role']) ?>

</td>

<td>

<form method="POST" class="password-form">

    <input
        type="hidden"
        name="user_id"
        value="<?= (int)$row['user_id'] ?>">

    <input
        type="password"
        name="new_password"
        id="pass<?= $row['user_id'] ?>"
        class="form-control password-input"
        placeholder="New Password"
        required>

    <button
        type="button"
        class="btn btn-dark"
        onclick="togglePassword('pass<?= $row['user_id'] ?>')">

        Show

    </button>

    <button
        type="submit"
        name="change_password"
        class="btn btn-dark">

        Change

    </button>

</form>

</td>

<td>

<?php if ($row['role'] === 'staff'): ?>

    <a
        href="users.php?delete=<?= (int)$row['user_id'] ?>"
        class="btn btn-danger"
        onclick="return confirm('Remove this staff account?')">

        Remove

    </a>

<?php else: ?>

    <span class="empty-text">
        Protected
    </span>

<?php endif; ?>

</td>

</tr>

<?php endwhile; ?>

</tbody>

</table>

</div>

</div>

</div>

<script>

function togglePassword(id){

    const input = document.getElementById(id);

    if(input.type === "password"){
        input.type = "text";
    } else {
        input.type = "password";
    }
}

</script>

</body>
</html>