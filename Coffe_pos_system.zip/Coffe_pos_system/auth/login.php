<?php
ob_start();
session_start();
include("../config/db.php");

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $username = trim($_POST['username']);
    $password = md5(trim($_POST['password']));

    $stmt = $conn->prepare("
        SELECT user_id, name, username, password, role
        FROM users
        WHERE username = ? AND password = ?
        LIMIT 1
    ");

    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();

    $result = $stmt->get_result();

    if ($result && $result->num_rows === 1) {

        $user = $result->fetch_assoc();
        $role = strtolower(trim($user['role']));

        session_regenerate_id(true);

        $_SESSION['user'] = $user;
        $_SESSION['role'] = $role;
        $_SESSION['user_id'] = $user['user_id'];

        // ROLE REDIRECTS
        if ($role === 'admin') {
            header("Location: ../admin/dashboard.php");
            exit;
        }

        if ($role === 'staff') {
          
        }

        if ($role === 'queue') {
            header("Location: ../queue/index.php");
            exit;
        }

        // INVALID ROLE
        session_destroy();
        header("Location: ../index.php?error=invalid_role");
        exit;
    }

    // INVALID LOGIN
    header("Location: ../index.php?error=invalid_login");
    exit;
}
?>