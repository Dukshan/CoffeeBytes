<?php
$conn = new mysqli("localhost","root","","coffee_pos");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>