<footer class="footer">
    <div class="footer-left">
        <h3>Coffee POS System</h3>
        <p>Inventory & Sales Management System</p>
    </div>

    <div class="footer-center">
    
    </div>

    <div class="footer-right">
        <p>Version 1.0</p>
        <p>© <?php echo date("Y"); ?> Coffee POS System</p>
    </div>
</footer>