<?php
// ✅ prevent session restart warning
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>CoffeeBytes</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body{
            background:#f5f5f5;
            min-height:100vh;
            display:flex;
            flex-direction:column;
        }

        .main-content{
            flex:1;
        }

        .navbar{
            box-shadow:0 2px 10px rgba(0,0,0,0.1);
        }

        .navbar-brand{
            font-size:1.4rem;
            font-weight:bold;
            color:#d4a373 !important;
        }

        .footer{
            background:#212529;
            color:white;
            padding:15px 30px;
            margin-top:40px;
        }

        .footer a{
            color:#d4a373;
            text-decoration:none;
        }

        .footer a:hover{
            color:white;
        }
    </style>
</head>

<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark px-4">
    <div class="container-fluid">

        <span class="navbar-brand">
            ☕ CoffeeBytes 
        </span>

        <div class="d-flex align-items-center gap-3">

            <?php if(isset($_SESSION['username'])): ?>
                <span class="text-white">
                    Welcome,
                    <strong><?php echo $_SESSION['username']; ?></strong>
                </span>
            <?php endif; ?>

            <a href="../auth/logout.php" class="btn btn-danger">
                Logout
            </a>

        </div>

    </div>
</nav>

<div class="container mt-4 main-content">