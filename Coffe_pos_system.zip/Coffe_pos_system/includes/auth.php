<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

include __DIR__ . "/../config/db.php";

if (!$conn) {
    die("DB CONNECTION FAILED");
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    die("INVALID REQUEST");
}

$username = trim($_POST['username'] ?? '');
$password = trim($_POST['password'] ?? '');

if ($username === '' || $password === '') {
    die("EMPTY INPUT");
}

$hashedPassword = md5($password);

/* FIXED QUERY */
$stmt = $conn->prepare("
    SELECT user_id, username, role
    FROM users
    WHERE username = ? AND password = ?
    LIMIT 1
");

if (!$stmt) {
    die("PREPARE FAILED: " . $conn->error);
}

$stmt->bind_param("ss", $username, $hashedPassword);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows === 0) {
    header("Location: ../index.php?error=1");
    exit();
}

$stmt->bind_result($user_id, $dbUser, $role);
$stmt->fetch();

/* SESSION */
$_SESSION['user_id'] = $user_id;
$_SESSION['username'] = $dbUser;
$_SESSION['role'] = $role;

/* FINAL FIXED REDIRECT LOGIC */
if ($role === "admin") {
    header("Location: ../admin/dashboard.php");
    exit();
}

if ($role === "staff") {
    header("Location: ../staff/dashboard.php");
    exit();
}

/* SUPERUSER GOES TO MAIN DASHBOARD */
if ($role === "superuser") {
    header("Location: ../dashboard.php");
    exit();
}

/* fallback safety */
header("Location: ../index.php?error=invalid_role");
exit();