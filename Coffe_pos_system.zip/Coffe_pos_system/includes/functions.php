<?php

// CHECK IF PRODUCT CAN BE MADE
function canMakeOrder($conn, $product_id, $qty){

    $recipe = $conn->query("
        SELECT ingredient_id, amount_ml
        FROM recipe
        WHERE product_id = $product_id
    ");

    if(!$recipe){
        die("Recipe query failed: " . $conn->error);
    }

    while($r = $recipe->fetch_assoc()){

        $needed = $r['amount_ml'] * $qty;

        $stockResult = $conn->query("
            SELECT stock_ml
            FROM ingredients
            WHERE ingredient_id = {$r['ingredient_id']}
        ");

        if(!$stockResult){
            die("Ingredient query failed: " . $conn->error);
        }

        $stockRow = $stockResult->fetch_assoc();
        $stock = $stockRow['stock_ml'] ?? 0;

        if($stock < $needed){
            return false;
        }
    }

    return true;
}


// CALCULATE HOW MANY PRODUCTS CAN STILL BE MADE
function maxProductServings($conn, $product_id){

    $recipe = $conn->query("
        SELECT ingredient_id, amount_ml
        FROM recipe
        WHERE product_id = $product_id
    ");

    if(!$recipe || $recipe->num_rows == 0){
        return 0;
    }

    $max = PHP_INT_MAX;

    while($r = $recipe->fetch_assoc()){

        $stockResult = $conn->query("
            SELECT stock_ml
            FROM ingredients
            WHERE ingredient_id = {$r['ingredient_id']}
        ");

        if(!$stockResult || $stockResult->num_rows == 0){
            return 0;
        }

        $stock = $stockResult->fetch_assoc()['stock_ml'] ?? 0;

        if($r['amount_ml'] <= 0){
            continue;
        }

        $possible = floor($stock / $r['amount_ml']);

        $max = min($max, $possible);
    }

    // FINAL SAFETY CHECK
    return ($max === PHP_INT_MAX) ? 0 : $max;
}
?>