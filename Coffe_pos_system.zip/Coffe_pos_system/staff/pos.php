<?php
session_start();
include("../config/db.php");

$role = $_SESSION['role'] ?? 'staff';

$success = false;
$error = "";

/* PRODUCTS QUERY */
$sql = "
SELECT p.*,
COALESCE(
(
    SELECT MIN(
        FLOOR(
            IFNULL(
                CASE 
                    WHEN i.expiration_date IS NULL THEN i.stock
                    WHEN i.expiration_date >= CURDATE() THEN i.stock
                    ELSE 0
                END
            ,0)
            / NULLIF(r.amount_ml,1)
        )
    )
    FROM recipes r
    LEFT JOIN ingredients i 
        ON r.ingredient_id = i.ingredient_id
    WHERE r.product_id = p.product_id
),0) AS max_servings
FROM products p
";

$products = $conn->query($sql);
if (!$products) die("SQL ERROR: " . $conn->error);

/* EXPIRATION CHECK */
function isExpired($conn, $ingredient_id){

    $stmt = $conn->prepare("
        SELECT expiration_date
        FROM ingredients
        WHERE ingredient_id = ?
    ");

    $stmt->bind_param("i", $ingredient_id);
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res->fetch_assoc();

    if(!$row || empty($row['expiration_date'])) return false;

    return $row['expiration_date'] < date('Y-m-d');
}

/* CHECKOUT */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['checkout']) && !empty($_POST['items'])) {

    $items = $_POST['items'];
    $total = 0;

    $blocked = false;
    $blockedItem = "";

    foreach ($items as $item) {

        $product_id = (int)$item['product_id'];

        $recipes = $conn->query("
            SELECT r.ingredient_id, i.name
            FROM recipes r
            LEFT JOIN ingredients i ON i.ingredient_id = r.ingredient_id
            WHERE r.product_id = $product_id
        ");

        while ($r = $recipes->fetch_assoc()) {

            if (isExpired($conn, $r['ingredient_id'])) {
                $blocked = true;
                $blockedItem = $r['name'];
                break 2;
            }
        }

        $total += (float)$item['subtotal'];
    }

    if ($blocked) {
        $error = "❌ Cannot place order. Expired ingredient: $blockedItem";
    } else {

        $user_id = $_SESSION['user']['user_id'] ?? 0;

        $stmt = $conn->prepare("
            INSERT INTO orders(user_id,total,status)
            VALUES(?,?,'Pending')
        ");

        $stmt->bind_param("id", $user_id, $total);
        $stmt->execute();

        $order_id = $stmt->insert_id;

        $stmt_item = $conn->prepare("
            INSERT INTO order_items(order_id,product_id,size,quantity,subtotal)
            VALUES(?,?,?,?,?)
        ");

        foreach ($items as $item) {

            $id = (int)$item['product_id'];
            $size = (int)$item['size'];
            $qty = (int)$item['quantity'];
            $subtotal = (float)$item['subtotal'];

            $stmt_item->bind_param("iiiid",
                $order_id, $id, $size, $qty, $subtotal
            );

            $stmt_item->execute();

            $recipes = $conn->query("
                SELECT * FROM recipes WHERE product_id = $id
            ");

            while ($r = $recipes->fetch_assoc()) {

                $multiplier = ($size == 22) ? 1.3 : 1;

                $deduct = $r['amount_ml'] * $multiplier * $qty;

                $conn->query("
                    UPDATE ingredients
                    SET stock = GREATEST(stock - $deduct,0)
                    WHERE ingredient_id = {$r['ingredient_id']}
                ");
            }
        }

        $success = true;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>POS System</title>

<style>

/* =========================
   BASE
========================= */
body{
    margin:0;
    font-family:'Segoe UI',sans-serif;
    background:#f7f3ee;
    color:#2b1d16;
}

/* =========================
   FIXED LAYOUT (NAVBAR SAFE)
========================= */
.layout{
    display:flex;
    min-height:100vh;
    width:100%;
}

/* SIDEBAR FIXED */
.sidebar{
    width:260px;
    min-width:260px;
    background:linear-gradient(180deg,#3b2f2f,#2a1f1b);
    color:#f5e6d3;
    padding:25px 20px;

    position:sticky;
    top:0;
    height:100vh;
    overflow-y:auto;
    flex-shrink:0;
}

.sidebar h2{
    text-align:center;
    color:#fff;
    margin-bottom:30px;
}

.sidebar a{
    display:block;
    padding:12px;
    margin-bottom:10px;
    color:#e8d5c0;
    text-decoration:none;
    border-radius:10px;
}

.sidebar a:hover{
    background:#5a3e36;
}

/* MAIN */
.main{
    flex:1;
    padding:20px;
    min-width:0;
}

/* ALERTS */
.alert-success{
    background:#d4edda;
    color:#155724;
    padding:10px;
    border-radius:8px;
    margin-bottom:10px;
}

.alert-error{
    background:#f8d7da;
    color:#721c24;
    padding:10px;
    border-radius:8px;
    margin-bottom:10px;
}

/* TOP BUTTON */
.top-bar{
    margin:10px 0 20px;
}

/* CONTENT LAYOUT */
.content{
    display:flex;
    gap:20px;
    align-items:flex-start;
    width:100%;
}

/* PRODUCTS GRID FIX */
.grid{
    flex:3;
    display:grid;
    grid-template-columns:repeat(auto-fill, minmax(200px, 1fr));
    gap:15px;
    min-width:0;
}

/* CARD */
.card{
    background:#fff;
    padding:14px;
    border-radius:12px;
    box-shadow:0 6px 16px rgba(0,0,0,0.08);
}

.name{font-weight:600;}
.price{color:#6f4e37;font-weight:600;}
.stock{font-size:13px;}
.out{color:#c62828;font-weight:bold;}
.ok{color:#2e7d32;font-weight:bold;}

/* BUTTONS */
.btn{
    padding:8px 10px;
    border:none;
    border-radius:8px;
    cursor:pointer;
}

.btn-dark{background:#3b2f2f;color:#fff;}
.btn-secondary{background:#a67c52;color:#fff;}

/* CART FIXED RIGHT (CLEAN + NO OVERLAP) */
.cart{
    flex:1;
    min-width:280px;
    max-width:320px;
    background:#fff;
    padding:15px;
    border-radius:12px;
    box-shadow:0 6px 20px rgba(0,0,0,0.1);

    position:sticky;
    top:20px;
    height:fit-content;
}

/* CART TEXT CLEAN */
#cart-body div{
    padding:8px 0;
    border-bottom:1px solid #eee;
    font-size:14px;
}

/* RESPONSIVE */
@media(max-width:900px){
    .layout{
        flex-direction:column;
    }

    .sidebar{
        width:100%;
        height:auto;
        position:relative;
    }

    .content{
        flex-direction:column;
    }

    .cart{
        position:relative;
        max-width:100%;
    }
}

</style>
</head>

<body>

<div class="layout">

<!-- SIDEBAR -->
<div class="sidebar">

    <h2>☕ CoffeeBytes</h2>

    <a href="../admin/dashboard.php">🏠 Dashboard</a>
    <a href="../admin/products.php">📦 Products</a>
    <a href="../admin/orders.php">🛒 Orders</a>
    <a href="../admin/recipes.php">🍹 Recipes</a>
    <a href="../admin/reports.php">📊 Reports</a>

    <?php if($role === 'admin'): ?>
        <a href="../admin/users.php">👥 Users</a>
    <?php endif; ?>

    <a href="../admin/inventory.php">🧪 Inventory</a>
    <a href="../auth/logout.php">🚪 Logout</a>

</div>

<!-- MAIN -->
<div class="main">

<h2>☕ POS System</h2>

<?php if($success): ?>
    <div class="alert-success">✅ Order placed successfully!</div>
<?php endif; ?>

<?php if($error): ?>
    <div class="alert-error"><?= $error ?></div>
<?php endif; ?>

<div class="top-bar">
    <a href="../admin/orders.php" class="btn btn-secondary">📦 View Order Status</a>
</div>

<div class="content">

<!-- PRODUCTS -->
<div class="grid">

<?php while($p=$products->fetch_assoc()): ?>
<?php $available = (int)$p['max_servings']; ?>

<div class="card">

<div class="name"><?= htmlspecialchars($p['name']) ?></div>
<div class="price">₱<?= number_format($p['price'],2) ?></div>

<?php if($available<=0): ?>
<div class="stock out">Out of Stock</div>
<?php else: ?>
<div class="stock ok"><?= $available ?> left</div>
<?php endif; ?>

<?php if($available>0): ?>
<div style="margin-top:8px;">
    <button class="btn btn-dark"
        onclick="addToCart(<?= $p['product_id'] ?>,'<?= $p['name'] ?>',<?= $p['price'] ?>,16,<?= $available ?>)">
        16oz
    </button>

    <button class="btn btn-secondary"
        onclick="addToCart(<?= $p['product_id'] ?>,'<?= $p['name'] ?>',<?= $p['price'] ?>,22,<?= $available ?>)">
        22oz
    </button>
</div>
<?php endif; ?>

</div>

<?php endwhile; ?>

</div>

<!-- CART -->
<div class="cart">

<h3>Cart</h3>

<form method="POST">

<div id="cart-body"></div>
<div id="hidden-inputs"></div>

<h3>Total: ₱<span id="total">0</span></h3>

<button class="btn btn-dark" name="checkout">Checkout</button>

</form>

</div>

</div>
</div>

<script>
let cart=[];

function addToCart(id,name,price,size,max){

let item=cart.find(c=>c.id==id&&c.size==size);

if(item){
if(item.quantity>=max){
alert("Stock limit reached");
return;
}
item.quantity++;
}else{
cart.push({id,name,price,size,quantity:1,max});
}

render();
}

function render(){

let body=document.getElementById("cart-body");
let hidden=document.getElementById("hidden-inputs");

body.innerHTML="";
hidden.innerHTML="";

let total=0;

cart.forEach((c,i)=>{

let sub=c.price*c.quantity*(c.size==22?1.3:1);
total+=sub;

body.innerHTML+=`
<div>
${c.name} (${c.size}oz) - ${c.quantity} - ₱${sub.toFixed(2)}
</div>
`;

hidden.innerHTML+=`
<input name="items[${i}][product_id]" value="${c.id}">
<input name="items[${i}][size]" value="${c.size}">
<input name="items[${i}][quantity]" value="${c.quantity}">
<input name="items[${i}][subtotal]" value="${sub}">
`;
});

document.getElementById("total").innerText=total.toFixed(2);
}
</script>

</body>
</html>