<?php
session_start();
include '../config/db.php';

if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    die("Cart is empty");
}

$cart = $_SESSION['cart'];


foreach ($cart as $item) {
    $product_id = $item['product_id'];
    $qty = $item['quantity'];

    $recipes = $conn->query("
        SELECT r.quantity_used_ml, i.stock_ml, i.name
        FROM recipes r
        JOIN ingredients i ON r.ingredient_id = i.id
        WHERE r.product_id = $product_id
    ");

    while ($r = $recipes->fetch_assoc()) {
        $needed = $r['quantity_used_ml'] * $qty;

        if ($r['stock_ml'] < $needed) {
            die("Not enough stock for " . $r['name']);
        }
    }
}

$total = 0;
foreach ($cart as $item) {
    $total += $item['subtotal'];
}

$conn->query("INSERT INTO orders (total) VALUES ($total)");
$order_id = $conn->insert_id;

foreach ($cart as $item) {
    $conn->query("
        INSERT INTO order_items 
        (order_id, product_id, quantity, subtotal, size_id, size)
        VALUES (
            $order_id,
            {$item['product_id']},
            {$item['quantity']},
            {$item['subtotal']},
            {$item['size_id']},
            '{$item['size']}'
        )
    );
}

foreach ($cart as $item) {
    $product_id = $item['product_id'];
    $qty = $item['quantity'];

    $recipes = $conn->query("
        SELECT * FROM recipes WHERE product_id = $product_id
    ");

    while ($r = $recipes->fetch_assoc()) {
        $used = $r['quantity_used_ml'] * $qty;

        $conn->query("
            UPDATE ingredients 
            SET stock_ml = stock_ml - $used
            WHERE id = {$r['ingredient_id']}
        ");
    }
}
unset($_SESSION['cart']);

header("Location: pos.php?success=1");
exit;