-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 22, 2026 at 09:13 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `coffee_pos`
--

-- --------------------------------------------------------

--
-- Table structure for table `ingredients`
--

CREATE TABLE `ingredients` (
  `ingredient_id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `unit` varchar(10) DEFAULT NULL,
  `stock` decimal(10,2) DEFAULT NULL,
  `min_stock_ml` decimal(10,2) DEFAULT 0.00,
  `expiration_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ingredients`
--

INSERT INTO `ingredients` (`ingredient_id`, `name`, `unit`, `stock`, `min_stock_ml`, `expiration_date`) VALUES
(1, 'Milk', 'ml', 720.00, 200.00, '2026-06-20'),
(2, 'Soda', 'ml', 350.00, 200.00, '2026-06-21'),
(3, 'Strawberry Syrup', 'ml', 300.00, 100.00, '2026-09-10'),
(4, 'Chocolate Powder', 'g', 850.00, 50.00, '2026-12-01'),
(5, 'Caramel Syrup', 'ml', 96.10, 100.00, '2026-05-28'),
(6, 'Matcha Powder', 'g', 490.00, 100.00, '2028-02-05'),
(8, 'Espresso Syrup', 'ml', 0.00, 100.00, '2026-10-05'),
(9, 'Mineral Water', 'ml', 2140.00, 1000.00, '2028-07-12'),
(10, 'Kiwi Syrup', 'ml', 235.00, 100.00, '2026-09-25'),
(11, 'Lemon Syrup', 'ml', 105.00, 100.00, '2026-09-20'),
(12, 'Watermelon Syrup', 'ml', 485.00, 100.00, '2026-10-01'),
(13, 'Nata de coco', 'g', 850.00, 100.00, '2026-11-15'),
(14, 'Whipped Cream', 'ml', 350.00, 50.00, '2026-05-24'),
(15, 'Granulated Sugar', 'g', 550.00, 100.00, '2027-02-24'),
(17, 'Salt', 'g', 298.70, 50.00, '2027-03-01'),
(19, 'Coffee Powder', 'g', 290.00, 50.00, '2026-07-23');

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `log_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `action` varchar(255) NOT NULL,
  `details` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`log_id`, `user_id`, `action`, `details`, `created_at`) VALUES
(1, 1, 'Order Update', 'Updated Order #27 to Completed', '2026-05-22 05:08:05'),
(2, 1, 'RESTOCK', 'Restocked Coffee Powder by 50 ml', '2026-05-22 05:21:29'),
(3, 1, 'DEDUCT', 'Deducted 350 ml from Coffee Powder', '2026-05-22 05:23:00'),
(4, 1, 'DELETE INGREDIENT', 'Deleted ingredient: Coffee Powder', '2026-05-22 05:23:06'),
(5, 1, 'ADD INGREDIENT', 'Added ingredient: Coffee Powder | Stock: 300 g', '2026-05-22 05:23:24'),
(6, 1, 'RESTOCK', 'Restocked Mineral Water by 2000 ml', '2026-05-22 05:26:11'),
(7, 1, 'DEDUCT', 'Deducted 87 g from Matcha Powder', '2026-05-22 05:27:11'),
(8, 1, 'RESTOCK', 'Restocked Matcha Powder by 500 g', '2026-05-22 05:27:46'),
(9, 1, 'Order Update', 'Updated Order #28 to Preparing', '2026-05-22 05:28:08'),
(10, 1, 'Order Update', 'Updated Order #28 to Completed', '2026-05-22 05:28:12');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `status` enum('Pending','Preparing','Completed','Cancelled') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `user_id`, `total`, `status`, `created_at`, `deleted_at`) VALUES
(12, 1, 50.70, 'Completed', '2026-05-21 04:54:31', NULL),
(13, 1, 104.00, 'Completed', '2026-05-21 05:42:18', NULL),
(14, 1, 50.70, 'Completed', '2026-05-21 06:12:45', NULL),
(15, 2, 288.00, 'Completed', '2026-05-21 10:06:57', NULL),
(16, 2, 104.00, 'Cancelled', '2026-05-22 03:27:11', '2026-05-22 12:02:30'),
(17, 2, 104.00, 'Cancelled', '2026-05-22 03:29:04', '2026-05-22 12:02:36'),
(18, 2, 104.00, 'Cancelled', '2026-05-22 03:29:16', '2026-05-22 12:02:43'),
(19, 2, 104.00, 'Cancelled', '2026-05-22 03:29:21', '2026-05-22 12:02:41'),
(20, 2, 104.00, 'Cancelled', '2026-05-22 03:32:26', '2026-05-22 12:02:38'),
(21, 2, 104.00, 'Cancelled', '2026-05-22 03:34:43', '2026-05-22 12:02:46'),
(22, 2, 104.00, 'Cancelled', '2026-05-22 03:38:16', '2026-05-22 12:02:48'),
(23, 2, 50.70, 'Completed', '2026-05-22 04:11:01', NULL),
(24, 1, 80.00, 'Completed', '2026-05-22 04:49:15', NULL),
(25, 1, 39.00, 'Cancelled', '2026-05-22 04:59:47', '2026-05-22 12:59:52'),
(26, 1, 50.70, 'Completed', '2026-05-22 05:02:19', NULL),
(27, 1, 50.70, 'Completed', '2026-05-22 05:07:58', NULL),
(28, 1, 80.00, 'Completed', '2026-05-22 05:28:02', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `subtotal` decimal(10,2) DEFAULT NULL,
  `size_id` int(11) DEFAULT NULL,
  `size` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `subtotal`, `size_id`, `size`) VALUES
(1, 2, 2, 1, 0.00, NULL, 22),
(2, 3, 5, 1, 0.00, NULL, 22),
(3, 3, 5, 1, 0.00, NULL, 16),
(4, 4, 5, 1, 0.00, NULL, 22),
(5, 4, 5, 1, 0.00, NULL, 16),
(6, 5, 5, 1, 0.00, NULL, 22),
(7, 5, 5, 1, 0.00, NULL, 16),
(8, 6, 5, 1, 0.00, NULL, 22),
(9, 6, 5, 1, 0.00, NULL, 16),
(10, 7, 5, 1, 0.00, NULL, 22),
(11, 7, 5, 1, 0.00, NULL, 16),
(12, 8, 5, 1, 0.00, NULL, 22),
(13, 8, 5, 1, 0.00, NULL, 16),
(14, 9, 5, 1, 0.00, NULL, 22),
(15, 9, 5, 1, 0.00, NULL, 16),
(16, 10, 5, 1, 123.50, NULL, 22),
(17, 10, 5, 1, 95.00, NULL, 16),
(18, 11, 5, 1, 95.00, NULL, 16),
(19, 11, 4, 1, 123.50, NULL, 22),
(20, 11, 3, 1, 123.50, NULL, 22),
(21, 12, 6, 1, 50.70, NULL, 22),
(22, 13, 2, 1, 104.00, NULL, 22),
(23, 14, 6, 1, 50.70, NULL, 22),
(24, 15, 5, 1, 104.00, NULL, 22),
(25, 15, 4, 1, 104.00, NULL, 22),
(26, 15, 9, 1, 80.00, NULL, 16),
(27, 16, 2, 1, 104.00, NULL, 22),
(28, 17, 2, 1, 104.00, NULL, 22),
(29, 18, 2, 1, 104.00, NULL, 22),
(30, 19, 2, 1, 104.00, NULL, 22),
(31, 20, 2, 1, 104.00, NULL, 22),
(32, 21, 2, 1, 104.00, NULL, 22),
(33, 22, 2, 1, 104.00, NULL, 22),
(34, 23, 8, 1, 50.70, NULL, 22),
(35, 24, 9, 1, 80.00, NULL, 16),
(36, 25, 7, 1, 39.00, NULL, 16),
(37, 26, 6, 1, 50.70, NULL, 22),
(38, 27, 7, 1, 50.70, NULL, 22),
(39, 28, 10, 1, 80.00, NULL, 16);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `stock` int(11) DEFAULT NULL,
  `base_price` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `name`, `category`, `price`, `stock`, `base_price`) VALUES
(2, 'Iced Americano', 'Cold Drink', 80.00, 5, NULL),
(3, 'Caramel Macchiato ', 'Cold Drinks', 80.00, 4, NULL),
(4, 'Matcha Latte', 'Cold Drinks', 80.00, 10, NULL),
(5, 'Salted Caramel Latte', 'Cold Drinks', 80.00, 12, NULL),
(6, 'Lemon Fruity Soda', 'Cold Drinks', 39.00, NULL, NULL),
(7, 'Watermelon Fruity Soda', 'Cold Drinks', 39.00, NULL, NULL),
(8, 'Kiwi Fruity Soda', 'Cold Drinks', 39.00, NULL, NULL),
(9, 'Strawberry Latte', 'Cold Drinks', 80.00, NULL, NULL),
(10, 'Dirty Matcha', 'Cold Drinks', 80.00, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `recipes`
--

CREATE TABLE `recipes` (
  `recipe_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `ingredient_id` int(11) DEFAULT NULL,
  `amount_ml` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `recipes`
--

INSERT INTO `recipes` (`recipe_id`, `product_id`, `ingredient_id`, `amount_ml`) VALUES
(1, 4, 1, 250.00),
(2, 4, 6, 10.00),
(3, 4, 7, 30.00),
(4, 2, 8, 100.00),
(5, 2, 9, 350.00),
(6, 6, 11, 50.00),
(7, 6, 2, 300.00),
(8, 6, 13, 20.00),
(9, 7, 12, 50.00),
(11, 7, 2, 300.00),
(12, 7, 13, 20.00),
(13, 5, 1, 250.00),
(16, 5, 5, 3.00),
(17, 3, 5, 5.00),
(18, 3, 8, 40.00),
(19, 3, 1, 250.00),
(20, 5, 16, 1.00),
(21, 5, 17, 1.00),
(22, 8, 13, 20.00),
(23, 8, 2, 300.00),
(24, 8, 10, 50.00),
(25, 9, 3, 50.00),
(26, 9, 1, 250.00),
(27, 10, 1, 130.00),
(28, 10, 6, 10.00),
(29, 10, 19, 10.00),
(30, 10, 9, 5.00);

-- --------------------------------------------------------

--
-- Table structure for table `sizes`
--

CREATE TABLE `sizes` (
  `size_id` int(11) NOT NULL,
  `name` varchar(10) DEFAULT NULL,
  `multiplier` decimal(3,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sizes`
--

INSERT INTO `sizes` (`size_id`, `name`, `multiplier`) VALUES
(1, '16oz', 1.00),
(2, '22oz', 1.30);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','staff','superuser') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `name`, `username`, `password`, `role`) VALUES
(1, 'Admin', 'admin', '0192023a7bbd73250516f069df18b500', 'admin'),
(2, 'Staff', 'staff', 'de9bf5643eabf80f4a56fda3bbb84483', 'staff'),
(5, 'Elshan', 'Staff2', '3e119ab537d3c4cc0c31b9277bfd785e', 'staff'),
(6, 'Owner', 'owner', 'f35364bc808b079853de5a1e343e7159', 'superuser');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ingredients`
--
ALTER TABLE `ingredients`
  ADD PRIMARY KEY (`ingredient_id`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD UNIQUE KEY `order_id` (`order_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `recipes`
--
ALTER TABLE `recipes`
  ADD PRIMARY KEY (`recipe_id`);

--
-- Indexes for table `sizes`
--
ALTER TABLE `sizes`
  ADD PRIMARY KEY (`size_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ingredients`
--
ALTER TABLE `ingredients`
  MODIFY `ingredient_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `recipes`
--
ALTER TABLE `recipes`
  MODIFY `recipe_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `sizes`
--
ALTER TABLE `sizes`
  MODIFY `size_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `logs`
--
ALTER TABLE `logs`
  ADD CONSTRAINT `logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
